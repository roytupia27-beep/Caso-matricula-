# Caso práctico: sistema de matrícula UNSCH 2026-II

Caso práctico de herencia múltiple en Python (MRO y problema del diamante).

**Estudiante:** Roy Cristian Tupiaranga
**Universidad:** Universidad Nacional San Cristóbal de Huamanga (UNSCH)
**Escuela:** Ingeniería de Sistemas

## Archivos

| Archivo | Descripción |
|---|---|
| `matricula_herencia.py` | Versión con herencia múltiple (Combinada1 y Combinada2). Muestra por qué los montos son distintos. |
| `matricula_rediseno.py` | Rediseño con composición: lista ordenada de reglas, con el orden explícito. |

## Cómo ejecutar

```bash
python matricula_herencia.py
python matricula_rediseno.py
```

## Resultado

| Estudiante | Versión | Monto |
|---|---|---|
| Luis Huamaní Cárdenas | Combinada1 | S/ 45.00 |
| Rosa Ccahuana Prado | Combinada2 | S/ 60.00 |

La diferencia se debe a que el orden de las clases base define el MRO, y el MRO define el orden en que se aplican la beca y los recargos. Dividir entre 2 antes o después de sumar los recargos da montos distintos.
